/* Since base is used as an eval source in preloading too, we must manually initialize it. */
self.sauceBaseInit();
