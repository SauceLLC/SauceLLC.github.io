import FitParser from './fit-parser.js';

window.jsfit = {
    FitParser
};
