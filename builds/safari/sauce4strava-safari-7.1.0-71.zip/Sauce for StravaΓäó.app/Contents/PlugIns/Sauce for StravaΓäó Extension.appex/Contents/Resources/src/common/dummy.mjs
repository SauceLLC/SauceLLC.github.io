// Fix web-ext linter error for module loader
export default 'dummy';
